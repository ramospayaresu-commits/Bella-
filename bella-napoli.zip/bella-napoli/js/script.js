// Menú hamburguesa
const boton = document.querySelector('.hamburguesa');
const nav = document.getElementById('nav');
boton.addEventListener('click', () => {
  const abierto = nav.classList.toggle('abierto');
  boton.setAttribute('aria-expanded', abierto);
});

// Botón "Volver arriba"
const arriba = document.getElementById('arriba');
window.addEventListener('scroll', () => {
  arriba.hidden = window.scrollY < 300;
});
arriba.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
